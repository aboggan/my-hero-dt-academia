import React from 'react';
import '../styles/components/hero.scss';

export default function Hero() {
  return (
    <section className="hero">
      <h1>My Hero DT Academia</h1>
    </section>
  );
}
