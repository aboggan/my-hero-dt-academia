import React from 'react';
import { useField } from '../context/FieldContext';

export default function ResetButton() {
  const { resetField } = useField();

  return (
    <div className="reset-button" style={{ textAlign: 'center', marginBottom: '1rem' }}>
      <button onClick={resetField}>
        🔄 Resetear alineación
      </button>
    </div>
  );
}
